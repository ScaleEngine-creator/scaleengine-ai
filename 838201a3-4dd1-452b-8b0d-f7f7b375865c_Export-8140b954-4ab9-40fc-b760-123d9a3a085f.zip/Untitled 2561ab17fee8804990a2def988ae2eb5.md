# Untitled

<!DOCTYPE html>
<html lang="ro">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ScaleEngine.AI</title>
<style>
body {
margin: 0;
font-family: Arial, sans-serif;
background: #0a0a0a;
color: #fff;
text-align: center;
}
header {
background: linear-gradient(90deg, #000, #0057ff);
padding: 20px;
}
header h1 {
margin: 0;
font-size: 2.5rem;
}
nav {
margin-top: 10px;
}
nav a {
color: #fff;
margin: 0 15px;
text-decoration: none;
font-weight: bold;
}
nav a:hover {
text-decoration: underline;
}
section {
padding: 60px 20px;
}
.btn {
display: inline-block;
margin-top: 20px;
padding: 12px 25px;
background: #0057ff;
color: #fff;
border-radius: 6px;
text-decoration: none;
font-weight: bold;
}
.btn:hover {
background: #003bb5;
}
footer {
background: #111;
padding: 20px;
margin-top: 50px;
}
</style>
</head>
<body>
<header>
<h1>ScaleEngine.AI</h1>
<p>Automatizări inteligente pentru afacerea ta</p>
<nav>
<a href="#servicii">Servicii</a>
<a href="#despre">Despre noi</a>
<a href="#contact">Contact</a>
</nav>
</header>

<section id="servicii">
<h2>Serviciile noastre</h2>
<p>✅ Chatboți inteligenți<br>✅ Automatizări business<br>✅ Optimizări cu AI</p>
<a href="#contact" class="btn">Află mai multe</a>
</section>

<section id="despre">
<h2>Despre ScaleEngine.AI</h2>
<p>Noi dezvoltăm soluții cu inteligență artificială pentru a duce afacerile la următorul nivel.
Eficiență, automatizare și inovație.</p>
</section>

<section id="contact">
<h2>Contact</h2>
<p>Email: <a [href="mailto:contact@scaleengine.ai](mailto:href=%22mailto:contact@scaleengine.ai)">[contact@scaleengine.ai](mailto:contact@scaleengine.ai)</a></p>
<p>Telefon: 0772 097 020</p>
</section>

<footer>
<p>© 2025 [ScaleEngine.AI](http://scaleengine.ai/) - Toate drepturile rezervate</p>
</footer>
</body>
</html>